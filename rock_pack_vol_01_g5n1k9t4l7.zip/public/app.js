// public/app.js
const openCameraBtn = document.getElementById('openCamera');
const fileInput = document.getElementById('fileInput');
const status = document.getElementById('status');

openCameraBtn.addEventListener('click', () => {
  fileInput.click();
});

fileInput.addEventListener('change', async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  status.textContent = 'Nalagam...';

  try {
    const form = new FormData();
    form.append('photo', f);

    const res = await fetch('/upload', { method: 'POST', body: form });
    const data = await res.json();
    if (data.ok) {
      status.innerHTML = `Nalaganje uspešno — <a href="${data.url}" target="_blank">Odpri sliko</a>`;
    } else {
      status.textContent = 'Napaka pri nalaganju: ' + (data.message || 'neznana');
    }
  } catch (err) {
    status.textContent = 'Napaka: ' + err.message;
  }
});
